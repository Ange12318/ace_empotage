<?php


// Liste des clients
$clients = [
    ["nom" => "Client 01"],
    ["nom" => "Client 02"],
    ["nom" => "Client 03"],
    ["nom" => "Client 04"],
    ["nom" => "Client 05"],
    ["nom" => "Client 06"],
    ["nom" => "Client 07"],
    ["nom" => "Client 08"],
    ["nom" => "Client 09"],
    ["nom" => "Client 10"],
    
];

// Liste des transitaires
$transitaires = [
    ["nom" => "SAHA TRANSIT"],
    ["nom" => "SIT Service export"],
    [ "nom" => "ASSIA COMMODITIES"],
    [ "nom" => "SIMAT"],
    [ "nom" => "AFRICA GBLOBAL LOGISTIC CI"],
    [ "nom" => "EBURNEENNE DE LOGISTIQUE ET TRANSIT"],
    [ "nom" => "MAERSK"],
    [ "nom" => "ITRAO"],
    
];

// Liste des banques
$banques = [
    ["nom" => "SGBCI"],
    ["nom" => "SIB"],
    ["nom" => "BDA"],
    ["nom" => "OIKOICREDIT"],
    ["nom" => "CORIS BANK"],
    ["nom" => "BNI"],
    ["nom" => "AFG BANK"],
];


